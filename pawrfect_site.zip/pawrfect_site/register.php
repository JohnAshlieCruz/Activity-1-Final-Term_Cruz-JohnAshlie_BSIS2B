<?php
require_once "config.php";

function h($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

$mess = [];
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $uname = trim($_POST['uname'] ?? '');
    $password = $_POST['password'] ?? '';
    $password2 = $_POST['password2'] ?? '';

    if ($password === $password2) {
        $stmt = $conn->prepare(
            "INSERT INTO users (username, password) VALUES (?, ?)"
        );

        $stmt->bind_param('ss', $uname, $password);

        if ($stmt->execute()) {
            $mess[] = "Registered successfully! Please wait for admin approval.";
        } else {
            $errors[] = "Username may already exist. Please try again.";
        }

        $stmt->close();
    } else {
        $errors[] = "Passwords do not match.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | PAWrfect</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>

<body style="margin:0; padding:20px; box-sizing:border-box; font-family:'Inter',sans-serif; background:#F8F9FB; color:#252A35; min-height:100vh; display:flex; justify-content:center; align-items:center;">

    <div style="background:#FFFFFF; width:100%; max-width:420px; padding:40px; border-radius:20px; box-shadow:0 10px 35px rgba(30,50,80,0.08); box-sizing:border-box;">

        <h1 style="font-size:32px; font-weight:800; color:#253B57; text-align:center; margin:0 0 8px;">
            PAW<span style="color:#D5A900;">rfect</span>
        </h1>

        <p style="text-align:center; color:#7B8492; font-size:13px; margin:0 0 30px;">
            Pet essentials & grooming
        </p>

        <h2 style="font-size:23px; font-weight:700; margin:0 0 8px;">
            Create your account
        </h2>

        <p style="color:#7B8492; font-size:14px; margin:0 0 25px;">
            Join PAWrfect and get started!
        </p>

        <?php foreach ($errors as $e): ?>
            <div style="background:#FFF0F0; color:#C0392B; padding:12px; border-radius:8px; font-size:13px; margin-bottom:15px;">
                <?= h($e) ?>
            </div>
        <?php endforeach; ?>

        <?php foreach ($mess as $m): ?>
            <div style="background:#EEF8F0; color:#287A43; padding:12px; border-radius:8px; font-size:13px; margin-bottom:15px;">
                <?= h($m) ?>
            </div>
        <?php endforeach; ?>

        <form action="" method="post">

            <div style="margin-bottom:18px;">
                <label for="uname" style="display:block; font-size:13px; font-weight:600; margin-bottom:8px;">
                    Username
                </label>

                <input
                    type="text"
                    name="uname"
                    id="uname"
                    placeholder="Enter your username"
                    required
                    autofocus
                    style="width:100%; padding:13px 14px; border:1px solid #E0E5EB; border-radius:9px; font-family:inherit; font-size:14px; box-sizing:border-box; outline:none;"
                >
            </div>

            <div style="margin-bottom:18px;">
                <label for="password" style="display:block; font-size:13px; font-weight:600; margin-bottom:8px;">
                    Password
                </label>

                <input
                    type="password"
                    name="password"
                    id="password"
                    placeholder="Enter your password"
                    required
                    style="width:100%; padding:13px 14px; border:1px solid #E0E5EB; border-radius:9px; font-family:inherit; font-size:14px; box-sizing:border-box; outline:none;"
                >
            </div>

            <div style="margin-bottom:18px;">
                <label for="password2" style="display:block; font-size:13px; font-weight:600; margin-bottom:8px;">
                    Confirm Password
                </label>

                <input
                    type="password"
                    name="password2"
                    id="password2"
                    placeholder="Re-enter your password"
                    required
                    style="width:100%; padding:13px 14px; border:1px solid #E0E5EB; border-radius:9px; font-family:inherit; font-size:14px; box-sizing:border-box; outline:none;"
                >
            </div>

            <button
                type="submit"
                style="width:100%; padding:14px; margin-top:8px; border:none; border-radius:9px; background:#F5D76E; color:#253B57; font-family:inherit; font-size:14px; font-weight:700; cursor:pointer;"
            >
                Create Account
            </button>

        </form>

        <p style="text-align:center; font-size:13px; color:#7B8492; margin-top:22px;">
            Already have an account?
            <a href="index.php" style="color:#253B57; font-weight:700; text-decoration:none;">
                Sign In
            </a>
        </p>

    </div>

</body>
</html>