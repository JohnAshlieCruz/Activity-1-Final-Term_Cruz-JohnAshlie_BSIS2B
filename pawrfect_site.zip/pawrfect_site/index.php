<?php
require_once "config.php";

function h($str){
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

$errors = [];

if($_SERVER['REQUEST_METHOD'] === "POST"){
    $uname = $_POST['uname'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT * FROM users WHERE username=?");
    $stmt->bind_param('s', $uname);
    $stmt->execute();

    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    $stmt->close();

    if($user && $password === $user['password']){
        if(trim($user['status']) !== "approved"){
            $errors[] = "Your account has not been approved by the admin.";
        }else{
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];

            header('Location: dashboard.php');
            exit;
        }
    }else{
        $errors[] = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>PAWrfect | Sign In</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>

<body style="margin:0; padding:20px; box-sizing:border-box; font-family:'Inter',sans-serif; background:#F8F9FB; color:#252A35; min-height:100vh; display:flex; align-items:center; justify-content:center;">

    <div style="width:100%; max-width:420px; background:#FFFFFF; padding:40px; border-radius:20px; border:1px solid #E9EDF3; box-shadow:0 10px 35px rgba(37,42,53,0.06); box-sizing:border-box;">

        <div style="text-align:center; margin-bottom:30px;">

            <h1 style="font-size:32px; font-weight:800; letter-spacing:-1.5px; margin:0;">
                PAW<span style="color:#D5A900;">rfect</span>
            </h1>

            <p style="color:#7A8494; font-size:13px; margin-top:6px;">
                Pet essentials & grooming
            </p>

        </div>

        <div style="margin-bottom:25px;">

            <h2 style="font-size:23px; font-weight:800; margin-bottom:8px;">
                Welcome back!
            </h2>

            <p style="font-size:14px; color:#7A8494;">
                Sign in to your PAWrfect account.
            </p>

        </div>

        <?php foreach ($errors as $e): ?>
            <div style="background:#FFF0F0; color:#C0392B; padding:12px; border-radius:8px; font-size:13px; margin-bottom:18px;">
                <?= h($e) ?>
            </div>
        <?php endforeach; ?>

        <form action="" method="post">

            <div style="margin-bottom:18px;">

                <label for="uname" style="display:block; font-size:13px; font-weight:700; margin-bottom:8px;">
                    Username
                </label>

                <input
                    type="text"
                    name="uname"
                    id="uname"
                    placeholder="Enter your username"
                    required
                    autofocus
                    style="width:100%; padding:13px 15px; border:1px solid #DCE2EA; border-radius:10px; font-family:'Inter',sans-serif; font-size:14px; outline:none; box-sizing:border-box;"
                >

            </div>

            <div style="margin-bottom:18px;">

                <label for="password" style="display:block; font-size:13px; font-weight:700; margin-bottom:8px;">
                    Password
                </label>

                <input
                    type="password"
                    name="password"
                    id="password"
                    placeholder="Enter your password"
                    required
                    style="width:100%; padding:13px 15px; border:1px solid #DCE2EA; border-radius:10px; font-family:'Inter',sans-serif; font-size:14px; outline:none; box-sizing:border-box;"
                >

            </div>

            <button
                type="submit"
                style="width:100%; padding:14px; background:#F5D76E; color:#252A35; border:none; border-radius:10px; font-family:'Inter',sans-serif; font-size:14px; font-weight:800; cursor:pointer; margin-top:8px;"
            >
                Sign In
            </button>

        </form>

        <div style="text-align:center; font-size:13px; color:#7A8494; margin-top:24px;">

            Don't have an account?

            <a href="register.php" style="color:#426F9E; font-weight:700; text-decoration:none;">
                Create one
            </a>

        </div>

    </div>

</body>
</html>